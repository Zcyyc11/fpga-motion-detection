"""Exercise the frozen evidence comparator with explicitly synthetic fixtures."""
import csv
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys

TOOLS = Path('D:/line3_cdnet_20261010_1700/tools')
sys.path.insert(0, str(TOOLS))
from prepare_dataset import SEQUENCES


def main():
    out = Path(sys.argv[1])
    out.mkdir(parents=True, exist_ok=False)
    real_meta = json.loads(Path('D:/line3_cdnet_20261010_1700/evaluation01/run.json').read_text(encoding='utf-8'))
    variants = [v[0] for v in real_meta['variants']]
    rows = []
    for seq, (_, first, last) in SEQUENCES.items():
        for variant in variants:
            for frame in range(first, last + 1):
                rows.append([seq, variant, frame, 2/3, 2/3, 2/3, 2, 1, 1, 3])
    assert len(rows) == 111498
    header = ['sequence', 'variant', 'frame', 'precision', 'recall', 'f1', 'tp', 'fp', 'fn', 'truth_pixels']
    csv_header = ['seq', 'variant', 'perframe_f1', 'official_f1']
    summary_rows = [[s, v, '0.6667', '0.6667'] for s in SEQUENCES for v in variants]
    cases = ['valid_synthetic', 'missing_frame', 'duplicate_frame', 'wrong_frame_id',
             'negative_count', 'truth_mismatch', 'rate_mismatch', 'missing_csv_key',
             'extra_csv_key', 'duplicate_csv_key', 'aggregate_mismatch',
             'reference_official_difference', 'reference_perframe_difference',
             'source_changed', 'reference_changed', 'dirty_source', 'run_failed']
    results = []
    for case in cases:
        dest = out / case
        dest.mkdir()
        altered = [list(r) for r in rows]
        actual = [list(r) for r in summary_rows]
        reference = [list(r) for r in summary_rows]
        meta = {'variants': real_meta['variants'], 'source_hashes': {'source.py': 'synthetic'},
                'source_hashes_after': {'source.py': 'synthetic'},
                'reference_hashes_before': {'ref.csv': 'synthetic'},
                'reference_hashes_after': {'ref.csv': 'synthetic'}, 'git_status_after': '', 'exit_code': 0}
        if case == 'missing_frame': altered.pop()
        if case == 'duplicate_frame': altered.append(altered[0])
        if case == 'wrong_frame_id': altered[0][2] = 0
        if case == 'negative_count': altered[0][6] = -1
        if case == 'truth_mismatch': altered[0][9] = 4
        if case == 'rate_mismatch': altered[0][5] = 0.5
        if case == 'missing_csv_key': actual.pop()
        if case == 'extra_csv_key': actual.append(['extra/sequence', variants[0], '0.6667', '0.6667'])
        if case == 'duplicate_csv_key': actual.append(actual[0])
        if case == 'aggregate_mismatch': actual[0][3] = '0.7777'
        if case == 'reference_official_difference': reference[0][3] = '0.5555'
        if case == 'reference_perframe_difference': reference[0][2] = '0.5555'
        if case == 'source_changed': meta['source_hashes_after'] = {'source.py': 'changed'}
        if case == 'reference_changed': meta['reference_hashes_after'] = {'ref.csv': 'changed'}
        if case == 'dirty_source': meta['git_status_after'] = ' M source.py'
        if case == 'run_failed': meta['exit_code'] = 1
        with gzip.open(dest / 'per_frame.csv.gz', 'wt', encoding='utf-8', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(header)
            writer.writerows(altered)
        for name, data in [('cdnet_official_results_r12.csv', actual), ('reference.csv', reference)]:
            with (dest / name).open('x', encoding='utf-8', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(csv_header)
                writer.writerows(data)
        (dest / 'run.json').write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding='utf-8')
        command = [sys.executable, '-X', 'utf8', str(TOOLS / 'compare_observed.py'), '--run', str(dest), '--reference', str(dest / 'reference.csv')]
        proc = subprocess.run(command, capture_output=True, encoding='utf-8')
        (dest / 'stdout.log').write_text(proc.stdout, encoding='utf-8')
        (dest / 'stderr.log').write_text(proc.stderr, encoding='utf-8')
        expected = 0 if case == 'valid_synthetic' else 1
        passed = proc.returncode == expected
        if case == 'valid_synthetic':
            summary = json.loads((dest / 'comparison/summary.json').read_text(encoding='utf-8'))
            passed &= summary['status'] == 'PASS' and summary['rows'] == 72 and summary['per_frame_rows'] == 111498
        results.append({'case': case, 'command': command, 'exit_code': proc.returncode,
                        'expected_exit_code': expected, 'pass': passed})
        print(case, proc.returncode, 'PASS' if passed else 'FAIL', flush=True)
    result = {'evidence_type': 'SYNTHETIC comparator tests, not real CDnet scores',
              'comparator_sha256': hashlib.sha256((TOOLS / 'compare_observed.py').read_bytes()).hexdigest(),
              'cases': results, 'passed': sum(r['pass'] for r in results), 'total': len(results)}
    (out / 'summary.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    return 0 if all(r['pass'] for r in results) else 1


if __name__ == '__main__':
    sys.exit(main())
