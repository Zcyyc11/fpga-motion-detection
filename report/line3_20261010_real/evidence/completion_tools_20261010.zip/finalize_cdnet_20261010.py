"""Audit and archive a finished real run. Never overwrite an earlier audit."""
import argparse
import csv
from datetime import datetime, timedelta, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

TOOLS = Path('D:/line3_cdnet_20261010_1700/tools')
sys.path.insert(0, str(TOOLS))
from prepare_dataset import SEQUENCES


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--run', type=Path, required=True)
    ap.add_argument('--out', type=Path, required=True)
    a = ap.parse_args()
    meta = json.loads((a.run / 'run.json').read_text(encoding='utf-8'))
    if 'exit_code' not in meta:
        raise RuntimeError('Run is not finished; leave all run files alone')
    a.out.mkdir(parents=True, exist_ok=False)
    checks = []

    def check(name, condition):
        checks.append({'name': name, 'pass': bool(condition)})

    source = Path(meta['source'])
    reference = source / 'src/ps/cdnet_official_results.csv'
    variants = [v[0] for v in meta['variants']]
    keys = {(s, v) for s in SEQUENCES for v in variants}
    completed = [(r['sequence'], r['variant']) for r in meta['completed']]
    check('original_entrypoint_exit_zero', meta['exit_code'] == 0)
    check('fixed_source_sha', meta['source_sha'] == 'ae5a7d8f77abe577a165b015a83d087f9cb65457')
    check('exact_r12_variant_ids', [v.split()[0] for v in variants] == ['V0', 'V12', 'V43', 'V45', 'V46', 'V47'])
    check('72_completed_unique_keys', len(completed) == 72 and len(set(completed)) == 72 and set(completed) == keys)
    check('completed_frame_counts', all(r['frames'] == SEQUENCES[r['sequence']][2] - SEQUENCES[r['sequence']][1] + 1 for r in meta['completed']))
    check('12_sequence_plans', set(meta['sequence_plans']) == set(SEQUENCES))
    plans_ok = True
    for seq, (_, first, last) in SEQUENCES.items():
        plan = meta['sequence_plans'].get(seq, {})
        temporal = [int(v) for v in (Path(meta['data_root']) / seq / 'temporalROI.txt').read_text().split()]
        plans_ok &= (temporal == [first, last] and plan.get('roi') == temporal
                     and plan.get('score') == temporal and plan.get('nwarm') == 100
                     and plan.get('first') == first - 100 and plan.get('count') == last - first + 101)
    check('plans_match_data_temporalROI_and_100_warmup', plans_ok)
    parity = meta['loader_equivalence']
    check('12_loader_parity_records', len(parity) == 12 and {p['sequence'] for p in parity} == set(SEQUENCES)
          and all(p['arrays_and_metrics_exact'] and p['loaded_frames'] == 130 and p['scored_frames'] == 30 and p['variants'] == 6 for p in parity))
    check('stderr_empty', (a.run / 'stderr.log').stat().st_size == 0)
    check('source_and_reference_hashes_unchanged_in_run', meta['source_hashes'] == meta['source_hashes_after']
          and meta['reference_hashes_before'] == meta['reference_hashes_after'])
    check('source_hashes_match_current_files', all(sha(source / p) == value for p, value in meta['source_hashes'].items()))
    check('reference_hashes_match_current_files', all(sha(source / 'src/ps' / p) == value for p, value in meta['reference_hashes_before'].items()))
    check('runner_hash_unchanged', sha(TOOLS / 'run_observed.py') == meta['wrapper_sha256'])
    check('data_verification_hash_unchanged', sha(Path(meta['data_root']).parent / 'verification.json') == meta['dataset_verification_sha256'])
    status = subprocess.check_output(['git', '-C', str(source), 'status', '--porcelain'], text=True).strip()
    head = subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD'], text=True).strip()
    check('frozen_git_clean_and_same_head', not status and not meta['git_status_before'] and not meta['git_status_after'] and head == meta['source_sha'])

    compare_code = None
    summary = None
    if all(c['pass'] for c in checks):
        command = [sys.executable, '-X', 'utf8', str(TOOLS / 'compare_observed.py'), '--run', str(a.run), '--reference', str(reference)]
        proc = subprocess.run(command, capture_output=True, encoding='utf-8')
        compare_code = proc.returncode
        (a.out / 'comparison.stdout.log').write_text(proc.stdout, encoding='utf-8')
        (a.out / 'comparison.stderr.log').write_text(proc.stderr, encoding='utf-8')
        (a.out / 'comparison.command.json').write_text(json.dumps(command, ensure_ascii=False, indent=2), encoding='utf-8')
        if (a.run / 'comparison/summary.json').exists():
            summary = json.loads((a.run / 'comparison/summary.json').read_text(encoding='utf-8'))
        check('independent_comparator_pass', compare_code == 0 and summary is not None and summary['status'] == 'PASS')
        check('111498_per_frame_rows', summary is not None and summary['per_frame_rows'] == 111498
              and summary['scored_frames_per_variant'] == 18583)
    inventory = {p.relative_to(a.run).as_posix(): {'bytes': p.stat().st_size, 'sha256': sha(p)}
                 for p in sorted(a.run.rglob('*')) if p.is_file()}
    archive = a.out / (a.run.name + '_complete_evidence.zip')
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as z:
        for relative in inventory:
            z.write(a.run / relative, relative)
    with zipfile.ZipFile(archive) as z:
        check('archive_crc_and_exact_members', z.testzip() is None and set(z.namelist()) == set(inventory))
        check('archive_member_hashes_match_disk', all(hashlib.sha256(z.read(name)).hexdigest() == value['sha256']
                                                   for name, value in inventory.items()))
    check('run_files_stable_during_archive', all(sha(a.run / name) == value['sha256'] for name, value in inventory.items()))
    result = {'checked_at': datetime.now(timezone(timedelta(hours=8))).isoformat(),
              'status': 'PASS' if all(c['pass'] for c in checks) else 'DIFFERENT_OR_FAILED',
              'checks': checks, 'run': str(a.run), 'source_sha': meta['source_sha'],
              'comparator_sha256': sha(TOOLS / 'compare_observed.py'), 'comparator_exit_code': compare_code,
              'run_exit_code': meta['exit_code'], 'run_elapsed_seconds': meta['elapsed_seconds'],
              'comparison': summary, 'inventory': inventory,
              'archive': {'file': str(archive), 'bytes': archive.stat().st_size, 'sha256': sha(archive)}}
    (a.out / 'audit.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result['status'] == 'PASS' else 1


if __name__ == '__main__':
    sys.exit(main())
