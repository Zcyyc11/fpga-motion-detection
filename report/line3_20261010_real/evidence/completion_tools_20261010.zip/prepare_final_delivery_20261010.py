"""Build final delivery only from a completed, independently verified real run."""
import csv
from datetime import datetime, timedelta, timezone
import hashlib
import json
from pathlib import Path
import shutil
import zipfile

root = Path(__file__).resolve().parents[1]
base = Path('D:/line3_cdnet_20261010_1700')
audit_path = base / 'final_audit02/audit.json'
audit = json.loads(audit_path.read_text(encoding='utf-8'))
assert audit['status'] == 'PASS' and all(c['pass'] for c in audit['checks'])
summary = audit['comparison']
assert summary['rows'] == 72 and summary['per_frame_rows'] == 111498
assert summary['csv_matches_reference_all_4dp_fields'] and not summary['differences']
run = base / 'evaluation02'
meta = json.loads((run / 'run.json').read_text(encoding='utf-8'))
v43 = next(v for v in summary['totals'] if v.startswith('V43 '))
actual = summary['totals'][v43]['actual_full_precision']
reference = summary['totals'][v43]['reference_from_4dp']
stamp = datetime.now(timezone(timedelta(hours=8))).strftime('%Y%m%d_%H%M%S')
backup = root / 'maintenance_20261010' / ('final_delivery_backup_' + stamp)
backup.mkdir(exist_ok=False)
report = root / 'captain_repo/report/line3_20261010_real/README.md'
evidence = report.parent / 'evidence'
shutil.copy2(report, backup / 'README_before_final.md')
shutil.copy2(root / 'handoff.md', backup / 'handoff_before_final.md')


def copy_new(src, name):
    dst = evidence / name
    if dst.exists():
        raise FileExistsError(dst)
    shutil.copy2(src, dst)
    assert hashlib.sha256(src.read_bytes()).digest() == hashlib.sha256(dst.read_bytes()).digest()


copy_new(Path(audit['archive']['file']), 'evaluation02_complete_evidence.zip')
copy_new(audit_path, 'evaluation02_final_audit.json')
copy_new(run / 'comparison/summary.json', 'evaluation02_comparison_summary.json')
copy_new(run / 'comparison/all_72_rows.csv', 'evaluation02_all_72_rows.csv')
copy_new(run / 'comparison/category_summary.csv', 'evaluation02_category_summary.csv')
copy_new(base / 'final_audit02_wait.json', 'evaluation02_completion_helper.json')
tools_zip = evidence / 'completion_tools_20261010.zip'
with zipfile.ZipFile(tools_zip, 'x', compression=zipfile.ZIP_DEFLATED) as z:
    for name in ['check_comparator_20261010.py', 'finalize_cdnet_20261010.py', 'wait_finalize_cdnet_20261010.py',
                 'prepare_final_delivery_20261010.py', 'preserve_interruption_1925.py']:
        z.write(root / 'maintenance_20261010' / name, name)
    for name in ['comparison.stdout.log', 'comparison.stderr.log', 'comparison.command.json']:
        z.write(base / 'final_audit02' / name, 'audit_process/' + name)
with zipfile.ZipFile(tools_zip) as z:
    assert z.testzip() is None
with (run / 'comparison/all_72_rows.csv').open(encoding='utf-8', newline='') as f:
    rows = list(csv.DictReader(f))
seq_table = '\n'.join('| {sequence} | {frames} | {score:.8f} | {reference_4dp} | 一致 |'.format(
    **r, score=float(r['official_f1_full'])) for r in rows if r['variant'] == v43)
total_table = '\n'.join(f"| {v.split()[0]} | {t['actual_full_precision']:.10f} | {t['reference_from_4dp']:.10f} |"
                        for v, t in summary['totals'].items())
section = f'''## 本轮最终结果：72项全部逐项一致

本轮实际V43的7类平均F1为 **{actual:.12f}**，保留三位小数为 **{actual:.3f}**。由历史四位小数CSV重算的均值为{reference:.12f}；两者差{actual-reference:+.12f}，来自序列分数是否先舍入。全部72行的 `official_f1` 和 `perframe_f1` 均与历史表四位小数完全一致。

这次结果来自12段真实数据、6个固定变体。每变体18,583计分帧，总计111,498行逐帧证据；比较器逐行重算P/R/F1和计数，核对每段每变体的完整帧号集合，再聚合到7类。没有缺帧、重复键或未解释差异。此结论是队伍选定12段/7类的软件复现，不是完整CDnet2014成绩或板端指标。

| 变体 | 本轮完整精度的类别平均 | 历史四位小数CSV重算均值 |
| --- | ---: | ---: |
{total_table}

V43的逐段结果如下；“一致”指两项CSV分数均一致，完整6变体明细见 `evidence/evaluation02_all_72_rows.csv`。

| 序列 | 计分帧 | 本轮整段F1 | 历史整段F1 | CSV对比 |
| --- | ---: | ---: | ---: | --- |
{seq_table}

最终运行目录 `D:/line3_cdnet_20261010_1700/evaluation02`，受测源码 `{meta['source_sha']}`。原入口退出码 **{meta['exit_code']}**，独立比较器退出码 **{audit['comparator_exit_code']}**，运行用时{meta['elapsed_seconds']:.1f}秒（含等价检查、数据预检和评分）。stderr为空；源码及全部历史CSV前后哈希一致，冻结checkout干净。最终核验{len(audit['checks'])}/{len(audit['checks'])}项通过。

最终运行命令：

```powershell
& 'D:/666666/Anaconda/python.exe' -X utf8 D:/line3_cdnet_20261010_1700/tools/run_observed.py --source D:/line3_cdnet_20261010_1700/source --data-root D:/cdnet2014_line3_20261010_1700/dataset --out D:/line3_cdnet_20261010_1700/evaluation02
```

等待器在评分进程结束后调用核验脚本，独立比较实际使用 `--run D:/line3_cdnet_20261010_1700/evaluation02`。命令、原始stdout/stderr、run.json、逐帧gzip、成绩CSV与comparison目录完整保存在 `evidence/evaluation02_complete_evidence.zip`。ZIP已逐项核对内容哈希并通过CRC检查；SHA256 `{audit['archive']['sha256']}`。

最终核验详情在 `evidence/evaluation02_final_audit.json`，摘要在 `evidence/evaluation02_comparison_summary.json`，各类分数在 `evidence/evaluation02_category_summary.csv`。本轮收尾工具及合成测试生成脚本另存 `evidence/completion_tools_20261010.zip`。下文保留中断过程与原始运行方式，结论以本节为准。

'''
content = report.read_text(encoding='utf-8')
old_lead = content.split('\n')[4]
assert old_lead.startswith('2026-10-10阶段记录。')
content = content.replace(old_lead, '2026-10-10最终记录。真实CDnet的12段/7类独立复现完成，72项CSV与历史记录逐项一致；电脑端模拟TCP接收与画框23/23检查通过。真实板端协议尚未提供，实际回传联调仍待队友配合。', 1)
content = content.replace('| V43/r12复现 | 隔离源码及运行器已启动；12段读取等价检查均通过，正式评分正在运行 | 全量结束、72行CSV及111,498行逐帧证据复核 |',
                          '| V43/r12复现 | 72/72项一致；111,498行逐帧证据完整，V43类别平均显示为0.737 | 本次选定软件子集无待补项 |')
content = content.replace('## 2026-10-10 19:25：', section + '## 2026-10-10 19:25：', 1)
content = content.replace('本轮实际值仍待全量评测结束。', '本轮实际值已由evaluation02完整复核，见最上方最终结果。')
content = content.replace('正式全量已进入snowFall，最终结果仍待结束。', '该段记录初次运行时的阶段状态；最终完整结果见上方evaluation02。')
content = content.replace('## 仍需接续\n\n等待当前评测结束，检查退出码与日志，运行完整集合比较，再把真实结果和差异补入本报告并同步原草稿PR。',
                          '## 交付范围与后续协作\n\n线三可在电脑上独立完成的真实数据复现、接收/画框模拟、材料纠错和报告证据已完成。')
report.write_text(content, encoding='utf-8')

body = (root / 'maintenance_20261010/line3_real_pr_body.md').read_text(encoding='utf-8')
start = body.index('全量r12评测已在隔离源码')
end = body.index('\n\n发现`cameraJitter', start)
body = body[:start] + f'''真实r12评测在冻结源码`{meta['source_sha']}`完成，原入口和独立比较器均退出0。12段/7类、6变体共72行CSV的两项四位小数分数与历史表全部一致；111,498条逐帧记录全部重算并检查帧号覆盖，V43类别平均F1为**{actual:.12f}（显示0.737）**。原算法及参数未调整，源码/参考CSV哈希保持不变。

按需读取与原缓存读取在12段各130帧上数组及六变体指标精确一致。比较器另通过17/17合成正反例检查。原evaluation01中断现场完整保留；evaluation02是最终成功运行，原始日志/逐帧证据/比较明细与ZIP哈希均已归档。上述结论仅限选定软件子集。''' + body[end:]
body = body.replace('补齐线三真实数据准备、可追溯评测运行器及电脑端模拟TCP接收/画框程序。', '完成线三真实CDnet独立复现，并补齐可追溯评测证据及电脑端模拟TCP接收/画框程序。')
body_path = root / 'maintenance_20261010/line3_real_final_pr_body.md'
with body_path.open('x', encoding='utf-8') as f:
    f.write(body)
for path in [report, body_path]:
    assert '\ufffd' not in path.read_text(encoding='utf-8')
record = {'created_at': datetime.now(timezone(timedelta(hours=8))).isoformat(), 'backup': str(backup),
          'v43_full_precision': actual, 'reference_rounded_mean': reference, 'report': str(report),
          'pr_body': str(body_path), 'archive_sha256': audit['archive']['sha256']}
with (root / 'maintenance_20261010/final_delivery_materials.json').open('x', encoding='utf-8') as f:
    json.dump(record, f, ensure_ascii=False, indent=2)
print(json.dumps(record, ensure_ascii=False, indent=2))
