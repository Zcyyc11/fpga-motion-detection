"""Preserve interrupted-run evidence and checkpoint the replacement run."""
from datetime import datetime, timedelta, timezone
import hashlib
import json
from pathlib import Path
import shutil
import zipfile

root = Path(__file__).resolve().parents[1]
base = Path('D:/line3_cdnet_20261010_1700')
evidence = root / 'captain_repo/report/line3_20261010_real/evidence'
stamp = datetime.now(timezone(timedelta(hours=8))).strftime('%Y%m%d_%H%M%S')
backup = root / 'maintenance_20261010' / ('checkpoint_' + stamp)
backup.mkdir(exist_ok=False)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def archive(src, dst):
    with zipfile.ZipFile(dst, 'x', compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(src.rglob('*')):
            if p.is_file():
                z.write(p, p.relative_to(src).as_posix())
    with zipfile.ZipFile(dst) as z:
        assert z.testzip() is None
    return {'path': dst.name, 'bytes': dst.stat().st_size, 'sha256': sha(dst), 'zip_crc': 'PASS'}


records = [archive(base / 'evaluation01', evidence / 'evaluation01_interrupted.zip'),
           archive(base / 'comparator_test01', evidence / 'comparator_test01_synthetic.zip')]
meta = json.loads((base / 'evaluation01/run.json').read_text(encoding='utf-8'))
assert len(meta['completed']) == 7 and 'exit_code' not in meta
record = {'checked_at': datetime.now(timezone(timedelta(hours=8))).isoformat(),
          'classification': 'INTERRUPTED_WITHOUT_FINAL_EXIT_CODE',
          'observed_last_boot': '2026-10-10T19:14:39+08:00',
          'original_pid_32740_absent': True, 'matching_evaluation_process_absent_before_restart': True,
          'original_last_output_at': '2026-10-10T17:09:37+08:00',
          'completed_items': 7, 'expected_items': 72,
          'reason_limit': 'Reboot observed; exact termination mechanism before reboot is not established.',
          'replacement_run': 'D:/line3_cdnet_20261010_1700/evaluation02',
          'replacement_pid': 27788, 'replacement_started_at': '2026-10-10T19:25:31+08:00',
          'source_sha': meta['source_sha'], 'archives': records,
          'original_files': {p.name: {'bytes': p.stat().st_size, 'sha256': sha(p)}
                             for p in sorted((base / 'evaluation01').iterdir()) if p.is_file()}}
with (evidence / 'interruption_20261010_1925.json').open('x', encoding='utf-8') as f:
    json.dump(record, f, ensure_ascii=False, indent=2)
shutil.copy2(base / 'comparator_test01/summary.json', evidence / 'comparator_tests_synthetic.json')

report = root / 'captain_repo/report/line3_20261010_real/README.md'
shutil.copy2(report, backup / 'line3_real_README_before.md')
content = report.read_text(encoding='utf-8')
addition = '''## 2026-10-10 19:25：评测中断后重新运行

原 `evaluation01` 留下7/72项，最后写入时间为17:09:37；19:25检查时PID 32740已不存在，系统最近启动时间为19:14:39。没有最终退出码或完整成绩表，不能把此轮算作全量完成。观察到电脑重启，但不能由此确定进程在重启前具体如何终止。

原目录未修改，逐文件哈希与现场记录见 `evidence/interruption_20261010_1925.json`，原始日志和不完整逐帧文件原样保存于 `evidence/evaluation01_interrupted.zip`。ZIP容器CRC通过不代表内部未完成的gzip可当完整评测证据。

替代运行于19:25:31启动，PID **27788**。源码仍为下文相同的 `ae5a7d8`，同一个运行器、同一组参数，唯一更换的参数是输出路径 `--out D:/line3_cdnet_20261010_1700/evaluation02`。后续比较命令应将 `--run` 改为此新目录；正在运行时不编辑运行器或读取未完成gzip来判定成败。

结果比较器的合成测试为 **17/17通过**：完整111,498行正例，以及漏帧、重复帧、错误编号、负计数、真值计数不符、逐帧率不符、缺/多/重复CSV键、汇总错误、历史分数差异、源码/参考变化、脏工作区和失败退出码等反例。测试输入与原始输出保存在 `evidence/comparator_test01_synthetic.zip`，摘要为 `evidence/comparator_tests_synthetic.json`。这是比较器测试，不是真实检测成绩。

'''
content = content.replace('## 数据来源与实际范围', addition + '## 数据来源与实际范围', 1)
report.write_text(content, encoding='utf-8')
handoff = root / 'handoff.md'
shutil.copy2(handoff, backup / 'handoff_before.md')
prefix = '''<!-- Hallmark · pre-emit critique: P5 H5 E5 S5 R5 V4; scope: interruption checkpoint. -->

# 最新检查点：原评测中断，evaluation02已启动

2026-10-10 19:25，本节覆盖下方旧PID和输出路径；尚非新会话交出点，当前会话继续工作。

- 原PID32740已不存在，evaluation01停在7/72项、无exit_code；最后日志17:09:37。系统LastBootUpTime为19:14:39。观察到重启，但具体终止机制未证实。原输出原样保留，并归档 `captain_repo/report/line3_20261010_real/evidence/evaluation01_interrupted.zip`。
- 替代运行 **PID27788**，19:25:31启动。原受测源码 `D:/line3_cdnet_20261010_1700/source`、SHA **ae5a7d8f77abe577a165b015a83d087f9cb65457**，原运行器未改；新输出 **D:/line3_cdnet_20261010_1700/evaluation02**，外层日志 `evaluation02_launcher.stdout.log`、`evaluation02_launcher.stderr.log`。
- 启动参数与旧命令一致，仅 `--out` 改为evaluation02。比较命令同理 `--run D:/line3_cdnet_20261010_1700/evaluation02`。先确认进程与exit_code再比较，禁止重复启动，禁止修改运行中源码/工具。
- 比较器17/17合成测试符合预期；不是真实分数。新脚本 `maintenance_20261010/check_comparator_20261010.py`，完整输出 `D:/line3_cdnet_20261010_1700/comparator_test01`，报告已追加中断和测试证据说明。原报告和handoff已备份于本次checkpoint目录。
- 全量最终结果仍未得到，仍需72项、111498行逐帧比较、归档报告、Git推同分支和原草稿PR。其他授权/保护规则/真实板端依赖/用户60%接续要求全部继承下文。外层无关.workbuddy/、handoff_workbuddy_review.md不提交不删除。

---

'''
handoff.write_text(prefix + handoff.read_text(encoding='utf-8'), encoding='utf-8')
for p in (report, handoff):
    assert '\ufffd' not in p.read_text(encoding='utf-8')
print(json.dumps({'backup': str(backup), 'archives': records}, ensure_ascii=False, indent=2))
