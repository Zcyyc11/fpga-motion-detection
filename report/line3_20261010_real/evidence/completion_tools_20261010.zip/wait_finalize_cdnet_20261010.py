"""One-run completion helper; never restarts the evaluation or edits its sources."""
import ctypes
from ctypes import wintypes
from datetime import datetime, timedelta, timezone
import json
from pathlib import Path
import subprocess
import sys
import time


def main():
    pid, run, out, record = int(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3]), Path(sys.argv[4])
    if out.exists() or record.exists():
        raise RuntimeError('Completion output already exists')
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    kernel.OpenProcess.restype = wintypes.HANDLE
    kernel.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
    kernel.WaitForSingleObject.restype = wintypes.DWORD
    kernel.CloseHandle.argtypes = [wintypes.HANDLE]
    handle = kernel.OpenProcess(0x00100000, False, pid)
    if not handle:
        raise ctypes.WinError(ctypes.get_last_error())
    started = time.monotonic()
    try:
        while True:
            state = kernel.WaitForSingleObject(handle, 0)
            if state == 0:
                break
            if state != 258:
                raise RuntimeError('Unexpected process wait state: ' + str(state))
            if time.monotonic() - started > 6 * 3600:
                raise RuntimeError('Six-hour helper timeout; evaluation was not stopped')
            time.sleep(15)
    finally:
        kernel.CloseHandle(handle)
    meta = json.loads((run / 'run.json').read_text(encoding='utf-8'))
    command = None
    if 'exit_code' not in meta:
        result, code = 'EVALUATION_INTERRUPTED_NO_FINAL_EXIT', 1
    else:
        command = [sys.executable, '-X', 'utf8', str(Path(__file__).with_name('finalize_cdnet_20261010.py')),
                   '--run', str(run), '--out', str(out)]
        code = subprocess.call(command)
        result = 'AUDIT_PASS' if code == 0 else 'AUDIT_DIFFERENT_OR_FAILED'
    with record.open('x', encoding='utf-8') as f:
        json.dump({'checked_at': datetime.now(timezone(timedelta(hours=8))).isoformat(), 'result': result,
                   'run': str(run), 'watched_pid': pid, 'command': command, 'exit_code': code}, f, ensure_ascii=False, indent=2)
    return code


if __name__ == '__main__':
    sys.exit(main())
